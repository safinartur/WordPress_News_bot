# Frontend (Vite + React)
```bash
cd frontend
npm i
cp .env.example .env
npm run dev
```
Сайт доступен на http://127.0.0.1:5173
